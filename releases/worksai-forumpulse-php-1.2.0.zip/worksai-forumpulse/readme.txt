=== worksai-forumpulse ===
Requires PHP: 8.1
License: MIT

Upload `worksai-forumpulse.zip` in WordPress Admin -> Plugins -> Add New -> Upload Plugin, or require `worksai-forumpulse-bridge.php` in PHP 8.2+.
